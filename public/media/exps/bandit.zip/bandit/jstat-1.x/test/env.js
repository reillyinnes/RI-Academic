// Hack to make jStat global for all tests.
jStat = require('../dist/jstat.js');
